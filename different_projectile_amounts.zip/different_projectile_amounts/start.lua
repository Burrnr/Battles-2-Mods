mod_metadata("name", "Different Projectile Amounts")
mod_metadata("author", "Burrnr")
mod_metadata("version", "1.0.0")



jet_binary_replace("game_data/game_project/assets/towers/tack_shooter/data/tack_shooter.tower_blueprint", "tack_shooter.tower_blueprint")
jet_binary_replace("game_data/game_project/assets/towers/druid/data/druid_blueprint.tower_blueprint", "druid_blueprint.tower_blueprint")
jet_binary_replace("game_data/game_project/assets/towers/super_monkey/data/super_monkey.tower_blueprint", "super_monkey.tower_blueprint")

